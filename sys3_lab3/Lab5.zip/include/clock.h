#ifndef _CLOCK_H
#define _CLOCK_H

void clock_set_next_event();
unsigned long get_cycles() ;
#endif
