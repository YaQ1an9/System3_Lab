#pragma once

#include "types.h"

void *memset(void *, int, uint64);
void *memcpy(void *dest, const void *src, uint64 n);
